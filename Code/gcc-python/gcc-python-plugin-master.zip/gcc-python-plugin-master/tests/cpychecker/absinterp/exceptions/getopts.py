print('-fexceptions')
